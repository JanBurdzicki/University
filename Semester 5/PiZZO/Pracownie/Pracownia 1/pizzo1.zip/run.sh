python3 pizzo1.py
