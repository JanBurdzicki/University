# python3 -m memory_profiler pizzo0.py
python3 pizzo0.py
